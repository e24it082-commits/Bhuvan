#include <stdio.h>
int main()
{
    int a =20 / 5 + 3 * 4 - 2;
    printf("%d",a);
    return 0;
}