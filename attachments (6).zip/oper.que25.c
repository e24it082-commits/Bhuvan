#include <stdio.h>
int main()
{
    int a =10 + 5 * 2;
    printf("%d",a);
    return 0;
}