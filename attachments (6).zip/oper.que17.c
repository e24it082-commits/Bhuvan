#include <stdio.h>
int main(){
    int a,b;
    printf("Enter the val of a nd b:\n");
    scanf("%d %d",&a,&b);
    printf("%d",a^b);
    return 0;
    
}