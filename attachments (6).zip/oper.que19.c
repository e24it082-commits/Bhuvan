#include <stdio.h>
int main(){
    int a;
    printf("Enter a:\n");
    scanf("%d",&a);
    printf("%d",a>>1);
    return 0;
}