#include <stdio.h>
int main(){
    int a;
    scanf("%d",&a);
    if(!(a==0)){
        printf("not zero");
    }
    else{
        printf("is zero");
    }
    return 0;
}
