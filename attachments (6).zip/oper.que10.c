#include <stdio.h>
int main(){
    int a=5;
    ++a;
    printf("%d\n",a);
    a++;
    printf("%d",a);
    return 0;

}